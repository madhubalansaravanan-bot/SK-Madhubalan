# Orbital Watch — Backend (Level 4)

A real backend service: it polls live TLE data from CelesTrak on a schedule,
runs the same SGP4-based conjunction screening as the browser version, stores
results in a database, exposes an API, and (optionally) emails you when a
close approach crosses a threshold you set.

This is genuine infrastructure — not a mock. It needs to run somewhere
persistent (not your laptop, not this chat) to actually be "operational."
Below is the fastest real path to that: **Render.com's free tier**, ~15
minutes, no cost.

---

## What's actually in here

| File | Purpose |
|---|---|
| `src/screening.js` | Real orbital mechanics — SGP4 propagation, closest-approach search, Pc calculation (same math as the browser tool, ported to Node) |
| `src/db.js` | SQLite storage — screening run history + every conjunction found |
| `src/alerts.js` | Optional email alerts when a conjunction is closer than your threshold |
| `src/server.js` | Express API + the scheduled job (`node-cron`) that re-screens automatically |
| `render.yaml` | Deploy config for Render.com (one-click-ish deploy) |
| `.env.example` | Every setting you can configure, documented |

## API endpoints once deployed

- `GET /api/health` — liveness check
- `GET /api/conjunctions` — latest screening results (closest first)
- `GET /api/runs` — history of past screening runs
- `POST /api/screen` — manually trigger a re-screen right now (requires `X-API-Key` header if `API_KEY` is set)

---

## Deploy it for real (Render.com, free tier)

**1. Get the code into a GitHub repo**
- Create a new repo on github.com (e.g. `orbital-watch-backend`)
- Upload everything in this folder **directly into the repo root** — `package.json` must sit at the top level of the repo, not inside a subfolder, or Render won't detect it

**2. Create a Render account**
- Go to render.com → sign up (free, no credit card required for the free tier)

**3. Create the service — two ways, pick whichever works**

*Option A: Blueprint (automatic, if it detects `render.yaml`)*
- Render dashboard → **New → Blueprint** → connect your repo → **Apply**

*Option B: Manual Web Service (more reliable, skips render.yaml entirely)*
- If Blueprint doesn't detect your repo or `render.yaml`, use this instead:
- Render dashboard → **New → Web Service** → connect your repo
- Environment: **Node**
- Build Command: `npm install`
- Start Command: `npm start`
- Instance Type: **Free**
- Add the environment variables from `.env.example` manually in the **Environment** tab (at minimum `SCREEN_GROUP_A`, `SCREEN_GROUP_B`)
- Click **Create Web Service**

**4. (Optional) Add email alerts**
- In the Render dashboard for your service → **Environment**
- Add: `ALERT_TO_EMAIL`, `SMTP_HOST`, `SMTP_USER`, `SMTP_PASS` (see `.env.example` for the full list and Gmail App Password instructions)
- For Gmail: you need an **App Password**, not your normal password — Google Account → Security → App Passwords
- Leave these unset and alerts just print to the Render logs instead — the service still works fully without email

**5. You're live**
- Render gives you a URL like `https://orbital-watch-backend.onrender.com`
- Test it: open `https://orbital-watch-backend.onrender.com/api/health` in a browser — should return `{"ok":true,...}`
- The first screening run kicks off automatically on boot; check `/api/conjunctions` a minute or two later

---

## Why Blueprint auto-detect sometimes fails

- **Files not at repo root.** If GitHub shows `orbital-watch-backend/src/...` instead of just `src/...` at the top level, Render can't find `package.json`. Fix: re-upload with the folder's *contents* at the repo root, not the folder itself.
- **Free-tier disk limitation.** Render's free plan doesn't support persistent disks — an earlier version of `render.yaml` included one, which could cause the blueprint to fail validation silently. The current version doesn't use a disk (see the note below on what that means for storage).
- **Repo visibility/permissions.** If the repo is private, make sure you granted Render access to it during the GitHub connection step.
- When in doubt, **Option B (manual Web Service)** above skips all of this — it ignores `render.yaml` completely and just needs Build/Start commands, which is more forgiving.

---

## Honest limitations of this Level-4 setup

- **Free tier sleeps.** Render's free web services spin down after 15 minutes of no HTTP traffic, and spin back up on the next request (~30s delay). The cron job still fires on schedule as long as the service is awake enough — for guaranteed uninterrupted scheduling, you'd need a paid instance (~$7/mo) or an external cron-ping service to keep it warm.
- **SQLite resets on redeploy (free tier).** Without a persistent disk (not available on the free plan), the database lives on the container's local, ephemeral filesystem — it survives restarts within the same deploy, but a fresh deploy wipes it. For a demo this is fine; for real long-term history, upgrade to a paid Render plan with a disk, or swap in a free hosted Postgres (e.g. Render's free Postgres tier, or Supabase) — `src/db.js` is the only file you'd need to change.
- **Pc still uses assumed uncertainty**, exactly as disclosed in the browser version — this backend doesn't have access to real tracking covariance either. Nothing free does.
- **No auth on the read endpoints.** `/api/conjunctions` and `/api/runs` are public by design (so a frontend can call them without a login flow). If you don't want that, add an API-key check to those routes too, the same way `/api/screen` is protected.

## Local testing (before you deploy, if you want)

```bash
cd orbital-watch-backend
cp .env.example .env
npm install
npm start
```

Then visit `http://localhost:3000/api/health`. Note: this sandbox environment I'm running in has no outbound network access, so I could not literally execute this myself — but the code has been written carefully and reviewed; test it locally to confirm before you deploy.
