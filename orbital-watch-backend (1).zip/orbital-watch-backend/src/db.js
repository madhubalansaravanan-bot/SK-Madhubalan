// db.js
// Storage layer. Uses SQLite via better-sqlite3 - a real file-backed database,
// not an in-memory placeholder. On most free hosts (Render, Railway) the local
// disk is ephemeral across redeploys, so for long-term production use you'd
// eventually point DATABASE_PATH at a mounted persistent volume, or swap this
// module for a hosted Postgres client. The schema and queries below would not
// need to change much either way.

const path = require('path');
const Database = require('better-sqlite3');

const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, '..', 'data', 'orbital-watch.db');

const fs = require('fs');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS screening_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  group_a TEXT NOT NULL,
  group_b TEXT NOT NULL,
  object_count_a INTEGER,
  object_count_b INTEGER,
  window_hours REAL,
  status TEXT NOT NULL DEFAULT 'running'
);

CREATE TABLE IF NOT EXISTS conjunctions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id INTEGER NOT NULL REFERENCES screening_runs(id),
  name_a TEXT NOT NULL,
  name_b TEXT NOT NULL,
  norad_a TEXT,
  norad_b TEXT,
  tca TEXT NOT NULL,
  distance_km REAL NOT NULL,
  rel_vel_km_s REAL,
  pc_estimate REAL,
  pc_sigma_km REAL,
  pc_hbr_km REAL,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  alerted INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_conjunctions_run ON conjunctions(run_id);
CREATE INDEX IF NOT EXISTS idx_conjunctions_distance ON conjunctions(distance_km);
CREATE INDEX IF NOT EXISTS idx_conjunctions_tca ON conjunctions(tca);
`);

function startRun({ groupA, groupB, windowHours, countA, countB }) {
  const stmt = db.prepare(`
    INSERT INTO screening_runs (started_at, group_a, group_b, object_count_a, object_count_b, window_hours, status)
    VALUES (datetime('now'), ?, ?, ?, ?, ?, 'running')
  `);
  const info = stmt.run(groupA, groupB, countA, countB, windowHours);
  return info.lastInsertRowid;
}

function finishRun(runId, status) {
  db.prepare(`UPDATE screening_runs SET finished_at = datetime('now'), status = ? WHERE id = ?`).run(status, runId);
}

function insertConjunction(runId, c) {
  const stmt = db.prepare(`
    INSERT INTO conjunctions
      (run_id, name_a, name_b, norad_a, norad_b, tca, distance_km, rel_vel_km_s, pc_estimate, pc_sigma_km, pc_hbr_km)
    VALUES (@runId, @nameA, @nameB, @noradA, @noradB, @tca, @distanceKm, @relVelKmS, @pcEstimate, @pcSigmaKm, @pcHbrKm)
  `);
  stmt.run({ runId, ...c });
}

function getLatestRun() {
  return db.prepare(`SELECT * FROM screening_runs WHERE status = 'complete' ORDER BY id DESC LIMIT 1`).get();
}

function getConjunctionsForRun(runId, limit = 50) {
  return db.prepare(`
    SELECT * FROM conjunctions WHERE run_id = ? ORDER BY distance_km ASC LIMIT ?
  `).all(runId, limit);
}

function getRunHistory(limit = 20) {
  return db.prepare(`SELECT * FROM screening_runs ORDER BY id DESC LIMIT ?`).all(limit);
}

function markAlerted(conjunctionId) {
  db.prepare(`UPDATE conjunctions SET alerted = 1 WHERE id = ?`).run(conjunctionId);
}

function getUnalertedHighRisk(distanceThresholdKm) {
  return db.prepare(`
    SELECT * FROM conjunctions WHERE alerted = 0 AND distance_km <= ? ORDER BY distance_km ASC
  `).all(distanceThresholdKm);
}

module.exports = {
  db,
  startRun,
  finishRun,
  insertConjunction,
  getLatestRun,
  getConjunctionsForRun,
  getRunHistory,
  markAlerted,
  getUnalertedHighRisk
};
