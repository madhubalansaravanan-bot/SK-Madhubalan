// alerts.js
// Sends an email when a newly-screened conjunction is closer than ALERT_DISTANCE_KM.
// Entirely optional: if SMTP_HOST/SMTP_USER/SMTP_PASS aren't set in the environment,
// this module just logs to the console instead of failing the whole service.

const nodemailer = require('nodemailer');

const ALERT_DISTANCE_KM = parseFloat(process.env.ALERT_DISTANCE_KM || '25');
const ALERT_TO = process.env.ALERT_TO_EMAIL;

let transporter = null;
if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
  transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: parseInt(process.env.SMTP_PORT || '587', 10),
    secure: process.env.SMTP_SECURE === 'true',
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
}

async function sendAlert(conjunction) {
  const subject = `[Orbital Watch] Close approach: ${conjunction.name_a} / ${conjunction.name_b} - ${conjunction.distance_km.toFixed(2)} km`;
  const body = [
    `Objects: ${conjunction.name_a} (NORAD ${conjunction.norad_a}) vs ${conjunction.name_b} (NORAD ${conjunction.norad_b})`,
    `Closest approach: ${conjunction.distance_km.toFixed(3)} km`,
    `Time of closest approach (TCA): ${conjunction.tca}`,
    conjunction.rel_vel_km_s ? `Relative velocity: ${conjunction.rel_vel_km_s.toFixed(2)} km/s` : null,
    conjunction.pc_estimate != null
      ? `Estimated Pc: ${conjunction.pc_estimate.toExponential(2)} (assumed sigma=${conjunction.pc_sigma_km} km, HBR=${conjunction.pc_hbr_km} km - NOT based on real tracking covariance)`
      : null,
    '',
    'This is a geometric screening result from public TLE data, not an official conjunction data message (CDM).'
  ].filter(Boolean).join('\n');

  if (!transporter || !ALERT_TO) {
    console.log('[alert - not sent, SMTP not configured]', subject);
    console.log(body);
    return { sent: false, reason: 'SMTP not configured' };
  }

  await transporter.sendMail({
    from: process.env.SMTP_FROM || process.env.SMTP_USER,
    to: ALERT_TO,
    subject,
    text: body
  });
  return { sent: true };
}

module.exports = { sendAlert, ALERT_DISTANCE_KM };
