// server.js
// Entry point. Exposes a small REST API and runs a scheduled background job
// that re-screens for real conjunctions on a timer, storing results in SQLite
// and (optionally) emailing an alert when something crosses ALERT_DISTANCE_KM.

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const cron = require('node-cron');

const db = require('./db');
const { runScreening } = require('./screening');
const { sendAlert, ALERT_DISTANCE_KM } = require('./alerts');

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_KEY; // required for the manual trigger endpoint only
const GROUP_A = process.env.SCREEN_GROUP_A || 'starlink';
const GROUP_B = process.env.SCREEN_GROUP_B || 'oneweb';
const LIMIT_A = parseInt(process.env.SCREEN_LIMIT_A || '20', 10);
const LIMIT_B = parseInt(process.env.SCREEN_LIMIT_B || '20', 10);
const WINDOW_HOURS = parseFloat(process.env.SCREEN_WINDOW_HOURS || '24');
const CRON_SCHEDULE = process.env.SCREEN_CRON || '0 */6 * * *'; // every 6 hours by default

const app = express();
app.use(cors());
app.use(express.json());

let isScreening = false;

async function runScreeningJob() {
  if (isScreening) {
    console.log('[screening] already in progress, skipping this tick');
    return;
  }
  isScreening = true;
  const runId = db.startRun({ groupA: GROUP_A, groupB: GROUP_B, windowHours: WINDOW_HOURS, countA: null, countB: null });
  console.log(`[screening] run ${runId} started: ${GROUP_A} x ${GROUP_B}, window=${WINDOW_HOURS}h`);
  try {
    const { results, countA, countB } = await runScreening({
      groupA: GROUP_A, groupB: GROUP_B, limitA: LIMIT_A, limitB: LIMIT_B, windowHours: WINDOW_HOURS
    });

    for (const r of results) {
      db.insertConjunction(runId, {
        nameA: r.nameA, nameB: r.nameB, noradA: r.noradA, noradB: r.noradB,
        tca: r.tca.toISOString(), distanceKm: r.distanceKm, relVelKmS: r.relVelKmS ?? null,
        pcEstimate: r.pcEstimate ?? null, pcSigmaKm: r.pcSigmaKm ?? null, pcHbrKm: r.pcHbrKm ?? null
      });
    }

    db.finishRun(runId, 'complete');
    console.log(`[screening] run ${runId} complete: ${results.length} candidates (of ${countA}x${countB} pairs), closest=${results[0]?.distanceKm?.toFixed(2)}km`);

    // Alerting: anything unalerted under the threshold gets an email (or console log if SMTP unset)
    const highRisk = db.getUnalertedHighRisk(ALERT_DISTANCE_KM);
    for (const c of highRisk) {
      try {
        await sendAlert(c);
        db.markAlerted(c.id);
      } catch (err) {
        console.error('[alert] failed to send:', err.message);
      }
    }
  } catch (err) {
    console.error('[screening] failed:', err.message);
    db.finishRun(runId, 'failed');
  } finally {
    isScreening = false;
  }
}

// ---------- API routes ----------

app.get('/api/health', (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

// Latest completed screening run + its results
app.get('/api/conjunctions', (req, res) => {
  const run = db.getLatestRun();
  if (!run) return res.json({ run: null, conjunctions: [] });
  const limit = Math.min(parseInt(req.query.limit || '25', 10), 100);
  const conjunctions = db.getConjunctionsForRun(run.id, limit);
  res.json({ run, conjunctions });
});

// History of past screening runs (for a trend view / audit trail)
app.get('/api/runs', (req, res) => {
  const limit = Math.min(parseInt(req.query.limit || '20', 10), 100);
  res.json({ runs: db.getRunHistory(limit) });
});

// Manually trigger a screening pass right now (protected by API_KEY if set)
app.post('/api/screen', async (req, res) => {
  if (API_KEY && req.headers['x-api-key'] !== API_KEY) {
    return res.status(401).json({ error: 'invalid or missing X-API-Key header' });
  }
  if (isScreening) {
    return res.status(409).json({ error: 'a screening run is already in progress' });
  }
  // Respond immediately; run in background so the request doesn't time out.
  res.json({ started: true });
  runScreeningJob();
});

app.listen(PORT, () => {
  console.log(`Orbital Watch backend listening on :${PORT}`);
  console.log(`Scheduled screening: "${CRON_SCHEDULE}" (${GROUP_A} x ${GROUP_B}, ${WINDOW_HOURS}h window)`);

  cron.schedule(CRON_SCHEDULE, runScreeningJob);

  // Run once on boot so the API has data immediately instead of waiting for the first cron tick.
  runScreeningJob();
});
