// screening.js
// Real orbital mechanics, running server-side. Same physics as the browser version:
// SGP4 propagation (satellite.js) for real positions, a coarse-then-fine search for
// true closest approach, and the standard 2D encounter-plane Pc formula. As with the
// browser version, Pc uses an ASSUMED position-uncertainty (sigma) because true
// tracking covariance isn't publicly available - this is disclosed in the output,
// not hidden.

const satellite = require('satellite.js');
const fetch = require('node-fetch');

const CELESTRAK_GROUPS = {
  stations: 'https://celestrak.org/NORAD/elements/gp.php?GROUP=stations&FORMAT=tle',
  active: 'https://celestrak.org/NORAD/elements/gp.php?GROUP=active&FORMAT=tle',
  starlink: 'https://celestrak.org/NORAD/elements/gp.php?GROUP=starlink&FORMAT=tle',
  oneweb: 'https://celestrak.org/NORAD/elements/gp.php?GROUP=oneweb&FORMAT=tle'
};

async function fetchTleGroup(groupKey) {
  const url = CELESTRAK_GROUPS[groupKey];
  if (!url) throw new Error(`Unknown TLE group: ${groupKey}`);
  const res = await fetch(url, { headers: { 'User-Agent': 'orbital-watch-backend/1.0' } });
  if (!res.ok) throw new Error(`CelesTrak fetch failed: HTTP ${res.status}`);
  const text = await res.text();
  return parseTle(text);
}

function parseTle(text) {
  const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  const sats = [];
  for (let i = 0; i + 2 < lines.length; i += 3) {
    const name = lines[i].replace(/^0 /, '');
    const l1 = lines[i + 1];
    const l2 = lines[i + 2];
    if (!l1 || !l2 || l1[0] !== '1' || l2[0] !== '2') continue;
    const norad = l1.substring(2, 7).trim();
    sats.push({ name, l1, l2, norad });
  }
  return sats;
}

function buildSatrecs(rawList, limit) {
  return rawList.slice(0, limit || rawList.length).map(raw => {
    try {
      return { name: raw.name, norad: raw.norad, satrec: satellite.twoline2satrec(raw.l1, raw.l2) };
    } catch (e) {
      return null;
    }
  }).filter(Boolean);
}

function eciDistanceKm(pvA, pvB) {
  if (!pvA || !pvA.position || !pvB || !pvB.position) return null;
  const dx = pvA.position.x - pvB.position.x;
  const dy = pvA.position.y - pvB.position.y;
  const dz = pvA.position.z - pvB.position.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

function closestApproach(satrecA, satrecB, startDate, windowHours, coarseStepSec) {
  let minDist = Infinity, minTime = startDate;
  const totalSec = windowHours * 3600;
  for (let t = 0; t <= totalSec; t += coarseStepSec) {
    const date = new Date(startDate.getTime() + t * 1000);
    const pvA = satellite.propagate(satrecA, date);
    const pvB = satellite.propagate(satrecB, date);
    const dist = eciDistanceKm(pvA, pvB);
    if (dist !== null && dist < minDist) { minDist = dist; minTime = date; }
  }
  const range = coarseStepSec * 2;
  let fineMin = minDist, fineTime = minTime, fineVelA = null, fineVelB = null;
  for (let dt = -range; dt <= range; dt += 1) {
    const date = new Date(minTime.getTime() + dt * 1000);
    const pvA = satellite.propagate(satrecA, date);
    const pvB = satellite.propagate(satrecB, date);
    const dist = eciDistanceKm(pvA, pvB);
    if (dist !== null && dist < fineMin) {
      fineMin = dist; fineTime = date;
      fineVelA = pvA.velocity; fineVelB = pvB.velocity;
    }
  }
  let relVelKmS = null;
  if (fineVelA && fineVelB) {
    const dvx = fineVelA.x - fineVelB.x, dvy = fineVelA.y - fineVelB.y, dvz = fineVelA.z - fineVelB.z;
    relVelKmS = Math.sqrt(dvx * dvx + dvy * dvy + dvz * dvz);
  }
  return { distanceKm: fineMin, tca: fineTime, relVelKmS };
}

// Standard 2D encounter-plane Pc: project relative position onto the plane
// perpendicular to relative velocity, then integrate an isotropic Gaussian
// (assumed sigma) over a disk of radius hbr (combined hard-body radius).
function pcNumericalIntegration(dx, dy, sigma, hbr) {
  const nR = 120, nTheta = 120;
  let sum = 0;
  const dR = hbr / nR;
  const dTheta = (2 * Math.PI) / nTheta;
  const norm = 1 / (2 * Math.PI * sigma * sigma);
  for (let i = 0; i < nR; i++) {
    const r = (i + 0.5) * dR;
    for (let j = 0; j < nTheta; j++) {
      const th = (j + 0.5) * dTheta;
      const x = r * Math.cos(th), y = r * Math.sin(th);
      const ex = -(((x - dx) ** 2 + (y - dy) ** 2) / (2 * sigma * sigma));
      sum += norm * Math.exp(ex) * r * dR * dTheta;
    }
  }
  return Math.min(sum, 1);
}

function vecSub(a, b) { return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z }; }
function vecDot(a, b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
function vecCross(a, b) { return { x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x }; }
function vecNorm(a) { const m = Math.sqrt(vecDot(a, a)) || 1; return { x: a.x / m, y: a.y / m, z: a.z / m }; }

function encounterPlaneMiss(satrecA, satrecB, tca) {
  const pvA = satellite.propagate(satrecA, tca);
  const pvB = satellite.propagate(satrecB, tca);
  if (!pvA.position || !pvB.position || !pvA.velocity || !pvB.velocity) return null;
  const rRel = vecSub(pvA.position, pvB.position);
  const vRel = vecSub(pvA.velocity, pvB.velocity);
  const vHat = vecNorm(vRel);
  let arbitrary = { x: 0, y: 0, z: 1 };
  if (Math.abs(vecDot(vHat, arbitrary)) > 0.99) arbitrary = { x: 1, y: 0, z: 0 };
  const u = vecNorm(vecCross(vHat, arbitrary));
  const w = vecCross(vHat, u);
  const dx = vecDot(rRel, u);
  const dy = vecDot(rRel, w);
  return { dx, dy, missDistance: Math.sqrt(dx * dx + dy * dy) };
}

/**
 * Run a full screening pass between two live-fetched TLE groups.
 * Returns an array of results sorted by closest approach first.
 */
async function runScreening({ groupA, groupB, limitA = 20, limitB = 20, windowHours = 24, coarseStepSec = 60, sigmaKm = 0.5, hbrKm = 0.02, topN = 25 }) {
  const [rawA, rawB] = await Promise.all([fetchTleGroup(groupA), fetchTleGroup(groupB)]);
  const setA = buildSatrecs(rawA, limitA);
  const setB = buildSatrecs(rawB, limitB);

  const startDate = new Date();
  const results = [];

  for (const a of setA) {
    for (const b of setB) {
      if (a.norad === b.norad) continue;
      const r = closestApproach(a.satrec, b.satrec, startDate, windowHours, coarseStepSec);
      if (!isFinite(r.distanceKm)) continue;
      results.push({
        nameA: a.name, nameB: b.name, noradA: a.norad, noradB: b.norad,
        distanceKm: r.distanceKm, tca: r.tca, relVelKmS: r.relVelKmS
      });
    }
  }

  results.sort((x, y) => x.distanceKm - y.distanceKm);
  const top = results.slice(0, topN);

  // Only compute the (more expensive) Pc for the closest candidates.
  for (const res of top) {
    const a = setA.find(s => s.norad === res.noradA);
    const b = setB.find(s => s.norad === res.noradB);
    const geom = encounterPlaneMiss(a.satrec, b.satrec, res.tca);
    if (geom) {
      res.pcEstimate = pcNumericalIntegration(geom.dx, geom.dy, sigmaKm, hbrKm);
      res.pcSigmaKm = sigmaKm;
      res.pcHbrKm = hbrKm;
    }
  }

  return { results: top, countA: setA.length, countB: setB.length };
}

module.exports = {
  CELESTRAK_GROUPS,
  fetchTleGroup,
  runScreening
};
