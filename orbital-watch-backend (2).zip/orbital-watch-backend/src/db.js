// db.js
// Storage layer - a plain JSON-file store, deliberately NOT using a native-compiled
// database driver. Native modules (like better-sqlite3) need to compile C++ at
// install time, which several free hosting containers (including Replit's
// deployment environment) don't reliably support - a failed native build there
// crashes the whole process before it can even start listening, which is exactly
// what an "Internal Server Error" platform crash page (not one from our own code)
// indicates. This module trades a little query elegance for something that
// cannot fail that particular way, on any host.

const fs = require('fs');
const path = require('path');

const DB_PATH = process.env.DATABASE_PATH || path.join(__dirname, '..', 'data', 'orbital-watch.json');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

function loadStore() {
  if (!fs.existsSync(DB_PATH)) {
    return { nextRunId: 1, nextConjunctionId: 1, runs: [], conjunctions: [] };
  }
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch (e) {
    console.error('[db] failed to parse store file, starting fresh:', e.message);
    return { nextRunId: 1, nextConjunctionId: 1, runs: [], conjunctions: [] };
  }
}

let store = loadStore();

function save() {
  // Write to a temp file then rename, so a crash mid-write can't corrupt the store.
  const tmpPath = DB_PATH + '.tmp';
  fs.writeFileSync(tmpPath, JSON.stringify(store));
  fs.renameSync(tmpPath, DB_PATH);
}

function startRun({ groupA, groupB, windowHours, countA, countB }) {
  const run = {
    id: store.nextRunId++,
    started_at: new Date().toISOString(),
    finished_at: null,
    group_a: groupA,
    group_b: groupB,
    object_count_a: countA,
    object_count_b: countB,
    window_hours: windowHours,
    status: 'running'
  };
  store.runs.push(run);
  save();
  return run.id;
}

function finishRun(runId, status) {
  const run = store.runs.find(r => r.id === runId);
  if (run) {
    run.finished_at = new Date().toISOString();
    run.status = status;
    save();
  }
}

function insertConjunction(runId, c) {
  const row = {
    id: store.nextConjunctionId++,
    run_id: runId,
    name_a: c.nameA,
    name_b: c.nameB,
    norad_a: c.noradA,
    norad_b: c.noradB,
    tca: c.tca,
    distance_km: c.distanceKm,
    rel_vel_km_s: c.relVelKmS ?? null,
    pc_estimate: c.pcEstimate ?? null,
    pc_sigma_km: c.pcSigmaKm ?? null,
    pc_hbr_km: c.pcHbrKm ?? null,
    created_at: new Date().toISOString(),
    alerted: 0
  };
  store.conjunctions.push(row);
  save();
}

function getLatestRun() {
  const complete = store.runs.filter(r => r.status === 'complete');
  if (!complete.length) return null;
  return complete.reduce((a, b) => (a.id > b.id ? a : b));
}

function getConjunctionsForRun(runId, limit = 50) {
  return store.conjunctions
    .filter(c => c.run_id === runId)
    .sort((a, b) => a.distance_km - b.distance_km)
    .slice(0, limit);
}

function getRunHistory(limit = 20) {
  return [...store.runs].sort((a, b) => b.id - a.id).slice(0, limit);
}

function markAlerted(conjunctionId) {
  const c = store.conjunctions.find(x => x.id === conjunctionId);
  if (c) { c.alerted = 1; save(); }
}

function getUnalertedHighRisk(distanceThresholdKm) {
  return store.conjunctions
    .filter(c => c.alerted === 0 && c.distance_km <= distanceThresholdKm)
    .sort((a, b) => a.distance_km - b.distance_km);
}

module.exports = {
  startRun,
  finishRun,
  insertConjunction,
  getLatestRun,
  getConjunctionsForRun,
  getRunHistory,
  markAlerted,
  getUnalertedHighRisk
};
